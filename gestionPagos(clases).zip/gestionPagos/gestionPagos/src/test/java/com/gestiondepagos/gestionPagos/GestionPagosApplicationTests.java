package com.gestiondepagos.gestionPagos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionPagosApplicationTests {

	@Test
	void contextLoads() {
	}

}
