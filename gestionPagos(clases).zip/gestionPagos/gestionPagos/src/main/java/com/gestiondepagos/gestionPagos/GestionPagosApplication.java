package com.gestiondepagos.gestionPagos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionPagosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionPagosApplication.class, args);
	}

}
