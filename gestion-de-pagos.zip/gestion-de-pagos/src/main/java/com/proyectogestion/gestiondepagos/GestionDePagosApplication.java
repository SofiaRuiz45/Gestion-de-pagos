package com.proyectogestion.gestiondepagos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionDePagosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionDePagosApplication.class, args);
	}
}
