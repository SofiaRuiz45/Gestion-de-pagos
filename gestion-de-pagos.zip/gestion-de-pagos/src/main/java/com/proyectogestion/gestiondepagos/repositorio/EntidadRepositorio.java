package com.proyectogestion.gestiondepagos.repositorio;

import com.proyectogestion.gestiondepagos.modelo.Entidad;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EntidadRepositorio extends JpaRepository <Entidad, Integer>{

}
