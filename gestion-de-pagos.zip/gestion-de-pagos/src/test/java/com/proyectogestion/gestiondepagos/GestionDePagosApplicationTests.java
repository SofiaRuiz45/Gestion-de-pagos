package com.proyectogestion.gestiondepagos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionDePagosApplicationTests {

	@Test
	void contextLoads() {
	}

}
